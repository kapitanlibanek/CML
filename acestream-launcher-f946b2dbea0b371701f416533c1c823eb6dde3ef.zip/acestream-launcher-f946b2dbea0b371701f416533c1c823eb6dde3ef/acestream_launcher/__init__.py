name = 'acestream_launcher'
